'''缓存的 Key'''

VCODE_KEY = 'VCode-%s'  # 验证码

REWIND_KEY = 'Rewind-%s-%s'  # 每日反悔计数

HOT_RANK = 'HOT_RANK'  # 热度排行
